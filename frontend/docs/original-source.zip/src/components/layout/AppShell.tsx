import { useTranslation } from "react-i18next";
import { Link, Outlet } from "react-router-dom";
import { ReceiptText } from "lucide-react";

import { ScenarioPanel } from "@/components/prototype/ScenarioPanel";
import { TxActivityDialog } from "@/components/tx/TxActivityDialog";
import { TxReceiptDialog } from "@/components/tx/TxReceiptDialog";

import { ActiveTxIndicator } from "./ActiveTxIndicator";
import { HeaderNav } from "./HeaderNav";
import { MobileNav } from "./MobileNav";
import { NetworkBadge } from "./NetworkBadge";
import { TestnetBanner } from "./TestnetBanner";
import { WalletButton } from "./WalletButton";

/**
 * 모든 화면에 적용되는 공통 셸.
 * 테스트넷 고지·내비게이션·네트워크·지갑·진행 중 거래 표시를 한 곳에서 관리합니다.
 */
export const AppShell = () => {
  const { t } = useTranslation();

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <TestnetBanner />
      <header className="sticky top-0 z-30 border-b border-border bg-card">
        <div className="page-container flex h-16 items-center gap-2">
          <Link to="/market" className="flex items-center gap-2">
            <span className="grid size-8 place-items-center rounded-lg bg-gradient-primary text-primary-foreground">
              <ReceiptText aria-hidden className="size-4" />
            </span>
            <span className="text-[17px] font-bold tracking-tight">Vestora</span>
          </Link>

          <HeaderNav className="ml-3 hidden md:flex" />

          <div className="ml-auto flex items-center gap-2">
            <ActiveTxIndicator />
            <NetworkBadge className="hidden lg:inline-flex" />
            <WalletButton />
            <MobileNav />
          </div>
        </div>
        <div className="page-container pb-2 lg:hidden">
          <NetworkBadge />
        </div>
      </header>

      <main className="page-container flex-1 py-6 pb-28">
        <Outlet />
      </main>

      <footer className="border-t border-border bg-card py-4">
        <div className="page-container text-caption text-muted-foreground">
          {t("app.footer")}
        </div>
      </footer>

      <ScenarioPanel />
      <TxActivityDialog />
      <TxReceiptDialog />
    </div>
  );
};
