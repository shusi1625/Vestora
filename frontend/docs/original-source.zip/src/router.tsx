import { Navigate } from "react-router-dom";

import { AppShell } from "./components/layout/AppShell";
import AssetsPage from "./pages/assets";
import ClaimDetailPage from "./pages/claim-detail";
import ComingSoonPage from "./pages/coming-soon";
import MarketPage from "./pages/market";
import NotFound from "./pages/NotFound";
import SellPage from "./pages/sell";

export const routers = [
  {
    path: "/",
    name: "app",
    element: <AppShell />,
    children: [
      {
        index: true,
        name: "home",
        element: <Navigate to="/market" replace />,
      },
      {
        path: "market",
        name: "market",
        element: <MarketPage />,
      },
      {
        path: "assets",
        name: "assets",
        element: <AssetsPage />,
      },
      {
        path: "claims/:id",
        name: "claimDetail",
        element: <ClaimDetailPage />,
      },
      {
        path: "claims/:id/sell",
        name: "claimSell",
        element: <SellPage />,
      },
      {
        path: "my/sales",
        name: "mySales",
        element: <ComingSoonPage screen="mySales" />,
      },
      {
        path: "manage/create",
        name: "paymentCreate",
        element: <ComingSoonPage screen="paymentCreate" />,
      },
      {
        path: "manage/issued",
        name: "paymentIssued",
        element: <ComingSoonPage screen="paymentIssued" />,
      },
      {
        path: "transactions",
        name: "transactions",
        element: <ComingSoonPage screen="transactions" />,
      },
    ],
  },
  /* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */
  {
    path: "*",
    name: "404",
    element: <NotFound />,
  },
];

declare global {
  interface Window {
    __routers__: typeof routers;
  }
}

window.__routers__ = routers;
